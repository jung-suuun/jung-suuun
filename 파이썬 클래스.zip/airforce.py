class AirForce():
    def take_off(self):
        pass
    def fly(self):
        pass
    def attack(self):
        pass
    def land(self):
        pass