from fighter import Fighter
from bomber import Bomber
def war_game(scenario):
    scenario.take_off()
    scenario.fly()
    scenario.attack()
    scenario.land()
f15=Fighter(3)
war_game(f15)
print()
b29=Bomber(5)
war_game(b29)    